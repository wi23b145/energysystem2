package at.technikum.energygui;

<<<<<<< HEAD

=======
>>>>>>> origin/fati
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

<<<<<<< HEAD

public class EnergyGuiApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        var url = EnergyGuiApplication.class.getResource(
                "/resources/at/technikum/energygui/hello-view.fxml"   // <— absoluter Pfad!
        );
        if (url == null) {
            throw new IllegalStateException("FXML not found on classpath: /at/technikum/energygui/hello-view.fxml");
        }
        FXMLLoader fxml = new FXMLLoader(url);
        Scene scene = new Scene(fxml.load(), 860, 520);
        stage.setTitle("Energy GUI");
=======
import java.io.IOException;

public class EnergyGuiApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(EnergyGuiApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
>>>>>>> origin/fati
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}