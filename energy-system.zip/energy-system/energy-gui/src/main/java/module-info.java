module at.technikum.energygui {
    requires javafx.controls;
    requires javafx.fxml;
<<<<<<< HEAD
    requires java.net.http;
    requires com.fasterxml.jackson.databind;

    opens at.technikum.energygui to javafx.fxml, com.fasterxml.jackson.databind;
=======


    opens at.technikum.energygui to javafx.fxml;
>>>>>>> origin/fati
    exports at.technikum.energygui;
}