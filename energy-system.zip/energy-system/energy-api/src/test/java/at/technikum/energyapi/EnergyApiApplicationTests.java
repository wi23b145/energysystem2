package at.technikum.energyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
