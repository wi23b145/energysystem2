package at.technikum.usageservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsageServiceApplication {
<<<<<<< HEAD

    public static void main(String[] args) {
        SpringApplication.run(UsageServiceApplication.class, args);
    }

=======
    public static void main(String[] args) {
        SpringApplication.run(UsageServiceApplication.class, args);
    }
>>>>>>> origin/fati
}
