package at.technikum.usageservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsageServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
