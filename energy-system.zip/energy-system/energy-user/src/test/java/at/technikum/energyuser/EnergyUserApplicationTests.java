package at.technikum.energyuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
