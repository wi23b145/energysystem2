package at.technikum.energyproducer.services;

public class ProducerService {
}
